package com.example.microservices.services.order;

public class OrderItem {
    private String itemId;
    private String name;
    private int quantity, price;

    public OrderItem() {}

    public OrderItem(String itemId, String name, int quantity, int price) {
        this.itemId = itemId;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public int getPrice() {
        return this.price;
    }
}
