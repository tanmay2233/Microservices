package com.example.microservices.services.order;

import com.example.microservices.services.inventory.InventoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    @Autowired
    private InventoryService inventoryService; // Optional - only if needed for local calls

    private final Map<String, String> orderStatus = new HashMap<>();

    private List<OrderItem> cartItems = new ArrayList<>();

    public void placeOrder(OrderEvent orderEvent) {
        String orderId = orderEvent.getOrderId() != null ? orderEvent.getOrderId() : UUID.randomUUID().toString();
        orderEvent.setOrderId(orderId);
        orderEvent.setStatus("ORDER_SUBMITTED");
        orderStatus.put(orderId, "ORDER_SUBMITTED");
        cartItems = orderEvent.getItems();

        logger.info("Publishing ORDER_SUBMITTED for order: {}", orderId);

        try {
            kafkaTemplate.send("inventory-topic", orderId, orderEvent);
            logger.info("Order with ID {} sent to InventoryService for validation", orderId);
        } catch (Exception e) {
            logger.error("Error publishing order {} to Kafka: {}", orderId, e.getMessage(), e);
        }
    }

    @KafkaListener(topics = "order-topic", groupId = "microservices-group")
    public void listen(OrderEvent event) {
        String orderId = event.getOrderId();
        String status = event.getStatus();
        List<OrderItem> items = event.getItems();

        logger.info("OrderService received event: {} for order: {}", status, orderId);

        switch (status) {
            case "ORDER_VALIDATED":
                logger.info("Inventory validated for order: {}", orderId);
                logger.info("Items after deduction:");
                for (OrderItem item : items) {
                    logger.info("Item: {} ({}), Remaining Qty: {}", item.getItemId(), item.getName(), item.getQuantity());
                }
                orderStatus.put(orderId, "ORDER_VALIDATED");

                // Send to payment topic
                kafkaTemplate.send("payment-topic", orderId,
                        new OrderEvent(orderId, "ORDER_VALIDATED", "Inventory OK", items));
                break;

            case "ORDER_FAILED":
                logger.warn("Inventory check failed for order: {}. Status set to ORDER_FAILED", orderId);
                orderStatus.put(orderId, "ORDER_FAILED");

                // ROLLBACK INVENTORY
                if (event.getItems() != null && !event.getItems().isEmpty()) {
                    logger.info("Rolling back inventory for failed order: {}", orderId);
                    inventoryService.rollbackInventory(cartItems);
                } else {
                    logger.warn("No items found to rollback for order: {}", orderId);
                }
                break;

            case "ORDER_SHIPPED":
                logger.info("Order {} has been shipped", orderId);
                orderStatus.put(orderId, "ORDER_DELIVERED");
                System.out.print("ORDER_DELIVERED");
                break;

            default:
                logger.warn("Unknown status {} received for order {}", status, orderId);
                break;
        }
    }
}
