package com.example.microservices.services.order;

import java.util.List;

public class OrderEvent {
    private String orderId;
    private String status;
    private String data;
    private List<OrderItem> items;
    private int orderTotal;

    public OrderEvent() {}

    public OrderEvent(String orderId, String status, String data) {
        this.orderId = orderId;
        this.status = status;
        this.data = data;
    }

    public OrderEvent(String orderId, int amtToBePaid, String status, List<OrderItem> items){
        this.orderTotal = amtToBePaid;
        this.status = status;
        this.orderId = orderId;
        this.items = items;
    }

    public OrderEvent(String orderId, String status, String data, List<OrderItem> items) {
        this.orderId = orderId;
        this.status = status;
        this.data = data;
        this.items = items;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public List<OrderItem> getItems() { return items; }

    public int getTotalPrice(List<OrderItem> itemsList){
        int total = 0;
        for(OrderItem item : itemsList){
            total += item.getQuantity()*item.getPrice();
        }
        return total;
    }
    public void setItems(List<OrderItem> items) { this.items = items; }
}
