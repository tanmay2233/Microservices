package com.example.microservices.services.shipping;

import com.example.microservices.services.order.OrderEvent;
import com.example.microservices.services.order.OrderItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShippingService {
    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    @KafkaListener(topics = "shipping-topic", groupId = "microservices-group")
    public void listen(OrderEvent event) {
        System.out.println("ShippingService received event: " + event.getStatus() + " for order: " + event.getOrderId());
        if ("ORDER_PAID".equals(event.getStatus())) {
            String orderId = event.getOrderId();
            List<OrderItem> items = event.getItems();
            System.out.println("Order shipped for order id: " + orderId);
            kafkaTemplate.send("order-topic", orderId, new OrderEvent(orderId, "ORDER_SHIPPED", "Shipped", items));
        }
    }
}