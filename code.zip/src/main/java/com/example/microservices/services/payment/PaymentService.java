package com.example.microservices.services.payment;

import com.example.microservices.services.inventory.InventoryService;
import com.example.microservices.services.order.OrderEvent;
import com.example.microservices.services.order.OrderItem;
import com.example.microservices.services.order.OrderService;
import com.example.microservices.services.shipping.ShippingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {
    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;
    private int walletBalance = 1000;
    @KafkaListener(topics = "payment-topic", groupId = "microservices-group")
    @KafkaListener(topics = "payment-topic", groupId = "microservices-group")
    public void listen(OrderEvent event) {
        System.out.println("PaymentService received event: " + event.getStatus() + " for order: " + event.getOrderId());

        int amtToBePaid = event.getTotalPrice(event.getItems()); // ✅ Use the amount directly
        List<OrderItem> items = event.getItems();

        if (amtToBePaid > walletBalance) {
            String orderId = event.getOrderId();
            System.out.println("Insufficient wallet balance for order: " + orderId);
            OrderEvent newEvent = new OrderEvent(orderId, "ORDER_FAILED", "Insufficient balance", items);
            kafkaTemplate.send("order-topic", orderId, newEvent);
        }
        else if ("ORDER_VALIDATED".equals(event.getStatus())) {
            String orderId = event.getOrderId();
            walletBalance -= amtToBePaid;
            System.out.println("Payment processed for order: " + orderId + ". Remaining wallet: " + walletBalance);
            OrderEvent newEvent = new OrderEvent(orderId, "ORDER_PAID", "Payment successful");
            kafkaTemplate.send("shipping-topic", orderId, newEvent);
        }
    }

}