package com.example.microservices.services.inventory;

import com.example.microservices.services.order.OrderEvent;
import com.example.microservices.services.order.OrderItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class InventoryService {

    @Autowired
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    private final Map<String, Integer> inventory = new HashMap<>();

    public InventoryService() {
        inventory.put("item1", 10);
        inventory.put("item2", 5);
        inventory.put("item3", 20);
    }

    public void rollbackInventory(List<OrderItem> items) {
        for (OrderItem item : items) {
            inventory.put(item.getItemId(), inventory.getOrDefault(item.getItemId(), 0) + item.getQuantity());
            System.out.println("Rolled back " + item.getQuantity() + " units of item ID: " + item.getItemId());
        }

        System.out.println("Inventory after rollback:");
        for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
            System.out.println("Item ID: " + entry.getKey() + ", Quantity: " + entry.getValue());
        }
    }


    @KafkaListener(topics = "inventory-topic", groupId = "microservices-group")
    public void listen(OrderEvent event) {
        System.out.println("InventoryService received event: " + event.getStatus() + " for order: " + event.getOrderId());

        if ("ORDER_SUBMITTED".equals(event.getStatus())) {
            String orderId = event.getOrderId();
            List<OrderItem> items = event.getItems();

            boolean canFulfill = true;

            // Print inventory before
            System.out.println("Inventory BEFORE processing order:");
            inventory.forEach((k, v) -> System.out.println(k + " => " + v));

            for (OrderItem item : items) {
                int availableQty = inventory.getOrDefault(item.getItemId(), 0);
                if (item.getQuantity() > availableQty) {
                    canFulfill = false;
                    break;
                }
            }

            if (canFulfill) {
                // Deduct quantities
                for (OrderItem item : items) {
                    inventory.put(item.getItemId(), inventory.get(item.getItemId()) - item.getQuantity());
                }

                System.out.println("Inventory validated for order: " + orderId);

                // Print inventory after
                System.out.println("Inventory AFTER processing order:");
                inventory.forEach((k, v) -> System.out.println(k + " => " + v));

                int amountToBePaid = event.getTotalPrice(event.getItems());
                System.out.println("Amount to be Paid: " + amountToBePaid);
                kafkaTemplate.send("payment-topic", orderId, new OrderEvent(orderId, amountToBePaid, event.getStatus(), items));
            } else {
                System.out.println("Inventory check failed for order: " + orderId);
                kafkaTemplate.send("order-topic", orderId, new OrderEvent(orderId, "ORDER_FAILED", "Insufficient Inventory", items));
            }
        }
    }
}
